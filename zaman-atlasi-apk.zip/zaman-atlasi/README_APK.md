# Zaman Atlası — Android uygulaması (APK)

**Zaman Atlası — Jeolojik ve Siyasi Dünya Tarihi**, Dünya Atlası projesinin telefon ve tablet sürümüdür.

| Özellik | Değer |
|---|---|
| Uygulama kimliği | `com.zamanatlasi.app` |
| En düşük Android sürümü | 7.0 (API 24) |
| Çalışma | Tamamen çevrimdışı. Yalnızca Vikipedi bağlantıları ve özel yazı tipleri için internet kullanılır. |

## GitHub ile APK oluşturma (tek zip)

1. GitHub'da **New repository** ile yeni bir depo oluşturun (örneğin `zaman-atlasi`). **Public** ya da **Private** seçebilirsiniz. "Add a README file" kutusunu işaretleyin ki depo boş olmasın.
2. Depoda **Add file → Create new file**'a tıklayın. Dosya adı kutusuna tam olarak `.github/workflows/apk.yml` yazın.
3. Zip içindeki `zaman-atlasi/.github/workflows/apk.yml` dosyasının içeriğini kopyalayıp editöre yapıştırın ve **Commit changes** ile kaydedin.
4. Depo ana sayfasına dönüp **Add file → Upload files** ile `zaman-atlasi-apk.zip` dosyasını sürükleyin ve **Commit changes**'a basın.
5. **Actions** sekmesini açın. "Zaman Atlası APK" işi otomatik başlar. Yeşil tik çıkmasını bekleyin; ilk derleme yaklaşık 5–8 dakika sürer.
6. Depo ana sayfasının sağındaki **Releases** bölümünde `Zaman Atlası 1.0.N` sürümünü açın ve `ZamanAtlasi-1.0.N.apk` dosyasını indirin. Bu sayfayı doğrudan telefondan açabilirsiniz. APK, iş akışı özet sayfasındaki **Artifacts** bölümünde de bulunur; oradan inen dosya zip içindedir.

## Telefona veya tablete kurma

1. APK dosyasını telefonda açın.
2. "Bilinmeyen kaynaklardan uygulama yükleme" izni sorulursa, dosyayı açtığınız uygulamaya (Chrome, Dosyalar vb.) izin verin.
3. Google Play Koruma "tanınmayan uygulama" uyarısı gösterebilir. Bunun nedeni uygulamanın Play Store dışından gelmesidir. **Yine de yükle** ile devam edebilirsiniz.

## Güncelleme

Yeni bir `zaman-atlasi-apk.zip` dosyasını **aynı adla** depoya yükleyin. İş akışı yeniden çalışır ve sürüm numarası otomatik artar. Yeni APK'yı eski sürümün üzerine kurabilirsiniz, uygulamayı silmenize gerek yoktur. Bu, her derlemenin projedeki sabit anahtarla (`android/app/zaman-atlasi.keystore`) imzalanması sayesinde mümkündür.

## Uygulamaya özel davranışlar

- **Geri tuşu:** Önce açık pencereyi, arama sonuçlarını, bilgi panelini ya da ayarları kapatır. Sonra Önemli Olaylar, Jeoloji ya da Karşılaştırma modundan Siyasi moda döner. En son uygulamadan çıkar.
- **Dışa aktarma:** PNG, CSV ve GeoJSON dosyaları telefonun **paylaşım menüsüyle** açılır. Buradan dosyayı kaydedebilir ya da bir uygulamayla paylaşabilirsiniz.
- **Telefon düzeni:** Ekran darsa düğmeler simgeye dönüşür. Aralık ayarları **⚙** düğmesinin arkasına alınır, kategori listeleri yana kaydırılır. Sayfa yakınlaştırması kapalıdır; yakınlaştırma yalnızca haritada iki parmakla yapılır.
- **Gizlenen düğmeler:** Tam ekran ve "Bağlantıyı kopyala" uygulamada anlamlı olmadığından gizlenmiştir.

## Proje yapısı

```
zaman-atlasi/
  package.json, package-lock.json   Capacitor 6 bağımlılıkları (sabit sürümler)
  capacitor.config.json             Uygulama adı, kimliği, renkler
  www/index.html                    Uygulamanın kendisi (Dünya Atlası tek dosya sürümü)
  android/                          Android projesi (simgeler, açılış ekranı, imzalama)
  resources/icon.svg, icon-512.png  Uygulama simgesi (özgün tasarım)
  scripts/www-hazirla.mjs           Web sürümünden www/index.html üretir
  .github/workflows/apk.yml         GitHub Actions derleme iş akışı
```

**İçeriği güncellemek için:** Dünya Atlası projesinde `node scripts/tek-dosya-olustur.mjs` çalıştırın. Ardından bu klasörde `node scripts/www-hazirla.mjs <yol>/dist/dunya-atlasi.html` çalıştırın ve yeni zip'i yükleyin.

**Simge:** Okyanus mavisi bir küre üzerinde Pangea süperkıtası (Tethys Denizi ile) ve saat çentikli, ok uçlu pirinç bir zaman halkasından oluşur. Özgün çizimdir. Android'in uyarlanabilir simgeleri için ön plan ve arka plan katmanları ayrıdır.

## Google Play'de yayımlamak isterseniz

Projedeki imzalama anahtarı ve parolaları herkese açıktır. Bu durum kişisel kurulum için sorun değildir, ama Play Store için **kendi gizli anahtarınızı** üretin:

1. Kendi anahtarınızı şu komutla üretin: `keytool -genkeypair -keystore benim.keystore -alias benim -keyalg RSA -keysize 2048 -validity 10000`
2. Anahtar dosyasını depoya eklemeyin. Onun yerine base64 hâlini ve parolaları GitHub **Settings → Secrets** bölümüne kaydedin.
3. İş akışında bu sırları `ZA_STORE_PASSWORD`, `ZA_KEY_ALIAS` ve `ZA_KEY_PASSWORD` ortam değişkenleri olarak verin. `build.gradle` bu değişkenleri okur.
4. Play Store APK yerine AAB ister: `./gradlew bundleRelease`.

## Bilinen sınırlılıklar

- **Derleme doğrulanmadı.** Bu sürüm geliştirme ortamında derlenemedi, çünkü Android SDK ve Gradle bağımlılıklarının indirilmesi oradan mümkün değildi. Android projesi Capacitor 6.2.3 ile oluşturuldu ve web kodu sahte bir Capacitor ortamında test edildi: geri tuşu ve paylaşım çalışıyor. Ancak ilk gerçek derleme GitHub Actions'ta yapılacak. Bir hata olursa Actions günlüğünün son satırlarını paylaşmanız yeterli.
- **Telefonda ilk açılış birkaç saniye sürebilir.** Uygulama 10 MB'lık gömülü veriyi açar.
- **Bazı katmanlar küçük ekranda kalabalık görünebilir.** Jeolojik modun hareket okları ve Önemli Olaylar'ın sonuç kutusu bunlara örnek. Sonuç kutusu × ile kapatılabilir; oklar Katmanlar sekmesinden kapatılabilir.
