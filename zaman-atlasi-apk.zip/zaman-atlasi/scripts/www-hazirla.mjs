// Web sürümünün tek dosyasından (dunya-atlasi.html) uygulama içi sayfayı üretir: www/index.html
// Kullanım: node scripts/www-hazirla.mjs ../dunya-atlasi/dist/dunya-atlasi.html
import fs from 'node:fs';
const src = process.argv[2];
if (!src) { console.error('Kaynak HTML yolu verin'); process.exit(1); }
let h = fs.readFileSync(src, 'utf8');
const rep = (a, b) => { if (!h.includes(a)) throw new Error('Bulunamadı: ' + a.slice(0, 60)); h = h.replace(a, b); };
rep('<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">',
    '<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">\n<meta name="theme-color" content="#143347">');
rep('<title>Dünya Atlası — Jeolojik ve Siyasi Tarih</title>', '<title>Zaman Atlası</title>');
rep('<h1 class="brand">Dünya Atlası <span>— Jeolojik ve Siyasi Tarih</span></h1>', '<h1 class="brand">Zaman Atlası <span>— Jeolojik ve Siyasi Dünya Tarihi</span></h1>');
fs.mkdirSync('www', { recursive: true });
fs.writeFileSync('www/index.html', h);
console.log(`www/index.html yazıldı (${(Buffer.byteLength(h) / 1048576).toFixed(1)} MB)`);
